#!/usr/bin/env python
# coding: utf-8

# In[1]:


filepath = 'EmailSpamCorpora/corpus/ham/0007.1999-12-14.farmer.ham.txt'
with open(filepath, 'r') as infile:
    ham_sample = infile.read()
    
print(ham_sample)


# In[2]:


filepath = 'EmailSpamCorpora/corpus/spam/0058.2003-12-21.GP.spam.txt'
with open(filepath, 'r') as infile:
    spam_sample = infile.read()
    
print(spam_sample)


# In[3]:


import glob
import os

emails = []
labels = []

filepath = 'EmailSpamCorpora/corpus/spam/'
for filename in glob.glob(os.path.join(filepath, '*.txt')):
    with open(filename, 'r', encoding = "ISO-8859-1") as infile:
        emails.append(infile.read().replace('\n', ' '))
        labels.append('spam')

filepath = 'EmailSpamCorpora/corpus/ham/'
for filename in glob.glob(os.path.join(filepath, '*.txt')):
    with open(filename, 'r', encoding = "ISO-8859-1") as infile:
        emails.append(infile.read().replace('\n', ' '))
        labels.append('ham')


# In[4]:


len(emails)
len(labels)


# In[5]:


emails[0]


# In[6]:


import nltk
from nltk.stem import WordNetLemmatizer
def letters_only(astr):
    return astr.isalpha()
lemmatizer = WordNetLemmatizer()

def clean_text(docs):
    cleaned_docs = []
    for doc in docs:
            cleaned_docs.append(' '.join([lemmatizer.lemmatize(word.lower())
                                          for word in doc.split()
                                          if letters_only(word)]))
    return cleaned_docs

cleaned_emails = clean_text(emails)
cleaned_emails[0]


# In[7]:


cleaned_token_emails = [nltk.word_tokenize(e) for e in cleaned_emails]
cleaned_token_emails[0]


# In[8]:


all_word_list = []

def removeNesting(l):
    for i in l:
        if type(i) == list:
                removeNesting(i)
        else:
            all_word_list.append(i)
    
removeNesting(cleaned_token_emails)

all_words = nltk.FreqDist(all_word_list)


# In[9]:


word_items = all_words.most_common(500)
word_features = [word for (word,count) in word_items]

def document_features(document, word_features):
    document_words = set(document)
    features = {}
    for word in word_features:
        features['V_{}'.format(word)] = (word in document_words)
    return features


# In[25]:


emails_label = [(e,l) for e,l in zip(cleaned_token_emails, labels)]


# In[31]:


import random
random.shuffle(emails_label)

featuresets = [(document_features(e, word_features), l) for (e,l) in emails_label]

train_set, test_set = featuresets[3879:], featuresets[:3879]
classifer = nltk.NaiveBayesClassifier.train(train_set)

print("Accuracy: ", nltk.classify.accuracy(classifer, test_set))


# In[37]:


# this function takes the number of folds, the feature sets
# it iterates over the folds, using different sections for training and testing in turn
#   it prints the accuracy for each fold and the average accuracy at the end
def cross_validation_accuracy(num_folds, featuresets):
    subset_size = int(len(featuresets)/num_folds)
    print('Each fold size:', subset_size)
    accuracy_list = []
    # iterate over the folds
    for i in range(num_folds):
        test_this_round = featuresets[(i*subset_size):][:subset_size]
        train_this_round = featuresets[:(i*subset_size)] + featuresets[((i+1)*subset_size):]
        # train using train_this_round
        classifier = nltk.NaiveBayesClassifier.train(train_this_round)
        # evaluate against test_this_round and save accuracy
        accuracy_this_round = nltk.classify.accuracy(classifier, test_this_round)
        print (i, accuracy_this_round)
        accuracy_list.append(accuracy_this_round)
    # find mean accuracy over all rounds
    print ('mean accuracy', sum(accuracy_list) / num_folds)
    
# perform the cross-validation on the featuresets with word features and generate accuracy
num_folds = 5
print(cross_validation_accuracy(num_folds, featuresets))


# In[36]:


goldlist = []
predictedlist = []
for (features, label) in test_set:
    	goldlist.append(label)
    	predictedlist.append(classifer.classify(features))
        
cm = nltk.ConfusionMatrix(goldlist, predictedlist)
print(cm.pretty_format(sort_by_count=True, show_percents=True, truncate=9))


# In[39]:


# Function to compute precision, recall and F1 for each label
#  and for any number of labels
# Input: list of gold labels, list of predicted labels (in same order)
# Output:  prints precision, recall and F1 for each label
def eval_measures(gold, predicted):
    # get a list of labels
    labels = list(set(gold))
    # these lists have values for each label 
    recall_list = []
    precision_list = []
    F1_list = []
    for lab in labels:
        # for each label, compare gold and predicted lists and compute values
        TP = FP = FN = TN = 0
        for i, val in enumerate(gold):
            if val == lab and predicted[i] == lab:  TP += 1
            if val == lab and predicted[i] != lab:  FN += 1
            if val != lab and predicted[i] == lab:  FP += 1
            if val != lab and predicted[i] != lab:  TN += 1
        # use these to compute recall, precision, F1
        recall = TP / (TP + FP)
        precision = TP / (TP + FN)
        recall_list.append(recall)
        precision_list.append(precision)
        F1_list.append( 2 * (recall * precision) / (recall + precision))

    # the evaluation measures in a table with one row per label
    print('\tPrecision\tRecall\t\tF1')
    # print measures for each label
    for i, lab in enumerate(labels):
        print(lab, '\t', "{:10.3f}".format(precision_list[i]),           "{:10.3f}".format(recall_list[i]), "{:10.3f}".format(F1_list[i]))
        
# call the function with our data
print(eval_measures(goldlist, predictedlist))

